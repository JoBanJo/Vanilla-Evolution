package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemSlimeyStuffs extends Item{
	
	public ItemSlimeyStuffs(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
