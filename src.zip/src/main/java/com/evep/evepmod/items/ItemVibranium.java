package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemVibranium extends Item{
	
	public ItemVibranium(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
