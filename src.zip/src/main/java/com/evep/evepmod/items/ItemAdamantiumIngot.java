package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemAdamantiumIngot extends Item{
	
	public ItemAdamantiumIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
