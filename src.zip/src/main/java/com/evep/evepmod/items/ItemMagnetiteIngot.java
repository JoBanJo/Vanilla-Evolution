package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemMagnetiteIngot extends Item{
	
	public ItemMagnetiteIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
