package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemMalachiteIngot extends Item{
	
	public ItemMalachiteIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
