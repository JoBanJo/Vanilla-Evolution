package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemRuby extends Item{
	
	public ItemRuby(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
