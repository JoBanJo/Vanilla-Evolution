package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemIridiumIngot extends Item{
	
	public ItemIridiumIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
