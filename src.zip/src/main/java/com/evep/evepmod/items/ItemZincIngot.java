package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemZincIngot extends Item{
	
	public ItemZincIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
