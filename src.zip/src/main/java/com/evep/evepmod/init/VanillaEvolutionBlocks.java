package com.evep.evepmod.init;

import com.evep.evepmod.VanillaEvolutionMod;
import com.evep.evepmod.blocks.BlockAdamantiumOre;
import com.evep.evepmod.blocks.BlockAluminumOre;
import com.evep.evepmod.blocks.BlockAmberOre;
import com.evep.evepmod.blocks.BlockAmethystOre;
import com.evep.evepmod.blocks.BlockAncientOre;
import com.evep.evepmod.blocks.BlockBaconOre;
import com.evep.evepmod.blocks.BlockBasalt;
import com.evep.evepmod.blocks.BlockBauxiteOre;
import com.evep.evepmod.blocks.BlockBerylOre;
import com.evep.evepmod.blocks.BlockBuildingBlock;
import com.evep.evepmod.blocks.BlockCarbonOre;
import com.evep.evepmod.blocks.BlockCobaltOre;
import com.evep.evepmod.blocks.BlockCopperOre;
import com.evep.evepmod.blocks.BlockDwarfStarAlloyOre;
import com.evep.evepmod.blocks.BlockElementalOre;
import com.evep.evepmod.blocks.BlockEnderiteOre;
import com.evep.evepmod.blocks.BlockEnergeticOre;
import com.evep.evepmod.blocks.BlockGneiss;
import com.evep.evepmod.blocks.BlockLeadOre;
import com.evep.evepmod.blocks.BlockLimestone;
import com.evep.evepmod.blocks.BlockMagnetiteOre;
import com.evep.evepmod.blocks.BlockMalachiteOre;
import com.evep.evepmod.blocks.BlockMarble;
import com.evep.evepmod.blocks.BlockMeteoriteOre;
import com.evep.evepmod.blocks.BlockNickelOre;
import com.evep.evepmod.blocks.BlockOnyxOre;
import com.evep.evepmod.blocks.BlockPeridotOre;
import com.evep.evepmod.blocks.BlockResourcesBlock;
import com.evep.evepmod.blocks.BlockRubyOre;
import com.evep.evepmod.blocks.BlockSeasonalOre;
import com.evep.evepmod.blocks.BlockSeleniteOre;
import com.evep.evepmod.blocks.BlockShale;
import com.evep.evepmod.blocks.BlockSilverOre;
import com.evep.evepmod.blocks.BlockSlimeOre;
import com.evep.evepmod.blocks.BlockSuperfoodOre;
import com.evep.evepmod.blocks.BlockTinOre;
import com.evep.evepmod.blocks.BlockTorchOre;
import com.evep.evepmod.blocks.BlockUltrafoodOre;
import com.evep.evepmod.blocks.BlockVibraniumOre;
import com.evep.evepmod.blocks.BlockWoodOre;
import com.evep.evepmod.blocks.BlockZincOre;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid=VanillaEvolutionMod.MODID)
public class VanillaEvolutionBlocks {

	public static Block malachite_ore;
	public static Block bacon_ore;
	public static Block torch_ore;
	public static Block wood_ore;
	public static Block limestone;
	public static Block basalt;
	public static Block gneiss;
	public static Block shale;
	public static Block marble;
	public static Block nickel_ore;
	public static Block bauxite_ore;
	public static Block aluminum_ore;
	public static Block silver_ore;
	public static Block lead_ore;
	public static Block zinc_ore;
	public static Block carbon_ore;
	public static Block tin_ore;
	public static Block copper_ore;
	public static Block cobalt_ore;
	public static Block meteorite_ore;
	public static Block enderite_ore;
	public static Block ultrafood_ore;
	public static Block superfood_ore;
	public static Block amber_ore;
	public static Block onyx_ore;
	public static Block seasonal_ore;
	public static Block ruby_ore;
	public static Block peridot_ore;
	public static Block amethyst_ore;
	public static Block adamantium_ore;
	public static Block vibranium_ore;
	public static Block dwarf_star_alloy_ore;
	public static Block slime_ore;
	public static Block energetic_ore;
	public static Block ancient_ore;
	public static Block elemental_ore;
	public static Block selenite_ore;
	public static Block beryl_ore;
	public static Block magnetite_ore;
	public static Block refined_basalt;
	public static Block refined_gneiss;
	public static Block refined_marble;
	public static Block refined_shale;
	public static Block basalt_bricks;
	public static Block gneiss_bricks;
	public static Block marble_bricks;
	public static Block shale_bricks;
	public static Block adamantium_block;
	public static Block aluminum_block;
	public static Block amber_block;
	public static Block amethyst_block;
	public static Block beryl_block;
	public static Block bronze_block;
	public static Block carbon_block;
	public static Block cobalt_block;
	public static Block copper_block;
	public static Block dwarf_star_alloy_block;
	public static Block elemental_block;
	public static Block enderite_block;
	public static Block energetic_block;
	public static Block iridium_block;
	public static Block lead_block;
	public static Block magnetite_block;
	public static Block malachite_block;
	public static Block nickel_block;
	public static Block onyx_block;
	public static Block peridot_block;
	public static Block ruby_block;
	public static Block selenite_block;
	public static Block silver_block;
	public static Block slimey_block;
	public static Block tin_block;
	public static Block vibranium_block;
	public static Block zinc_block;
	
	public static void init() {
		malachite_ore = new BlockMalachiteOre("malachite_ore", Material.ROCK).setHardness(1.5f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		malachite_ore.setHarvestLevel("pickaxe", 2);
		
		bacon_ore = new BlockBaconOre("bacon_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		bacon_ore.setHarvestLevel("pickaxe", 1);
		
		torch_ore = new BlockTorchOre("torch_ore", Material.ROCK).setHardness(1f).setLightLevel(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		torch_ore.setHarvestLevel("pickaxe", 1);
		
		wood_ore = new BlockWoodOre("wood_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		wood_ore.setHarvestLevel("pickaxe", 1);
		
		limestone = new BlockLimestone("limestone", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		limestone.setHarvestLevel("pickaxe", 1);
		
		basalt = new BlockBasalt("basalt", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		basalt.setHarvestLevel("pickaxe", 1);
		
		gneiss = new BlockGneiss("gneiss", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		gneiss.setHarvestLevel("pickaxe", 1);
		
		shale = new BlockShale("shale", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		shale.setHarvestLevel("pickaxe", 1);
		
		marble = new BlockMarble("marble", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		marble.setHarvestLevel("pickaxe", 1);
		
		nickel_ore = new BlockNickelOre("nickel_ore", Material.ROCK).setHardness(1.5f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		nickel_ore.setHarvestLevel("pickaxe", 2);
		
		bauxite_ore = new BlockBauxiteOre("bauxite_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		bauxite_ore.setHarvestLevel("pickaxe", 2);
		
		aluminum_ore = new BlockAluminumOre("aluminum_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		aluminum_ore.setHarvestLevel("pickaxe", 2);
		
		silver_ore = new BlockSilverOre("silver_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		silver_ore.setHarvestLevel("pickaxe", 2);
		
		lead_ore = new BlockLeadOre("lead_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		lead_ore.setHarvestLevel("pickaxe", 2);
		
		zinc_ore = new BlockZincOre("zinc_ore", Material.ROCK).setHardness(1.5f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		zinc_ore.setHarvestLevel("pickaxe", 2);
		
		carbon_ore = new BlockCarbonOre("carbon_ore", Material.ROCK).setHardness(1f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		carbon_ore.setHarvestLevel("pickaxe", 2);
		
		tin_ore = new BlockTinOre("tin_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		tin_ore.setHarvestLevel("pickaxe", 2);
		
		copper_ore = new BlockCopperOre("copper_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		copper_ore.setHarvestLevel("pickaxe", 2);
		
		cobalt_ore = new BlockCobaltOre("cobalt_ore", Material.ROCK).setHardness(1f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		cobalt_ore.setHarvestLevel("pickaxe", 2);
		
		meteorite_ore = new BlockMeteoriteOre("meteorite_ore", Material.ROCK).setHardness(1f).setResistance(10f).setLightLevel(1f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		meteorite_ore.setHarvestLevel("pickaxe", 2);
		
		enderite_ore = new BlockEnderiteOre("enderite_ore", Material.ROCK).setHardness(8f).setResistance(25f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		enderite_ore.setHarvestLevel("pickaxe", 3);
		
		ultrafood_ore = new BlockUltrafoodOre("ultrafood_ore", Material.ROCK).setHardness(4f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		ultrafood_ore.setHarvestLevel("pickaxe", 3);
		
		superfood_ore = new BlockSuperfoodOre("superfood_ore", Material.ROCK).setHardness(5f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		superfood_ore.setHarvestLevel("pickaxe", 3);
		
		amber_ore = new BlockAmberOre("amber_ore", Material.ROCK).setHardness(5f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		amber_ore.setHarvestLevel("pickaxe", 3);
		
		onyx_ore = new BlockOnyxOre("onyx_ore", Material.ROCK).setHardness(5f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		onyx_ore.setHarvestLevel("pickaxe", 3);
		
		seasonal_ore = new BlockSeasonalOre("seasonal_ore", Material.ROCK).setHardness(3f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		seasonal_ore.setHarvestLevel("pickaxe", 3);
		
		ruby_ore = new BlockRubyOre("ruby_ore", Material.ROCK).setHardness(3f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		ruby_ore.setHarvestLevel("pickaxe", 3);
		
		peridot_ore = new BlockPeridotOre("peridot_ore", Material.ROCK).setHardness(4f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		peridot_ore.setHarvestLevel("pickaxe", 3);
		
		amethyst_ore = new BlockAmethystOre("amethyst_ore", Material.ROCK).setHardness(3f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		amethyst_ore.setHarvestLevel("pickaxe", 3);
		
		adamantium_ore = new BlockAdamantiumOre("adamantium_ore", Material.ROCK).setHardness(4f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		adamantium_ore.setHarvestLevel("pickaxe", 3);
		
		vibranium_ore = new BlockVibraniumOre("vibranium_ore", Material.ROCK).setHardness(4f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		vibranium_ore.setHarvestLevel("pickaxe", 3);
		
		dwarf_star_alloy_ore = new BlockDwarfStarAlloyOre("dwarf_star_alloy_ore", Material.ROCK).setResistance(10f).setHardness(5f).setLightLevel(1f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		dwarf_star_alloy_ore.setHarvestLevel("pickaxe", 3);
		
		slime_ore = new BlockSlimeOre("slime_ore", Material.ROCK).setHardness(3f).setResistance(10f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		slime_ore.setHarvestLevel("pickaxe", 3);
		
		energetic_ore = new BlockEnergeticOre("energetic_ore", Material.ROCK).setHardness(10f).setResistance(2000f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		energetic_ore.setHarvestLevel("pickaxe", 4);
		
		ancient_ore = new BlockAncientOre("ancient_ore", Material.ROCK).setHardness(15f).setResistance(2000f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		ancient_ore.setHarvestLevel("pickaxe", 4);
		
		elemental_ore = new BlockElementalOre("elemental_ore", Material.ROCK).setHardness(12f).setResistance(2000f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		elemental_ore.setHarvestLevel("pickaxe", 4);
		
		selenite_ore = new BlockSeleniteOre("selenite_ore", Material.ROCK).setHardness(10f).setResistance(2000f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		selenite_ore.setHarvestLevel("pickaxe", 4);
		
		beryl_ore = new BlockBerylOre("beryl_ore", Material.ROCK).setHardness(6f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		beryl_ore.setHarvestLevel("pickaxe", 3);
		
		magnetite_ore = new BlockMagnetiteOre("magnetite_ore", Material.ROCK).setHardness(9f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabOres);
		magnetite_ore.setHarvestLevel("pickaxe", 3);
		
		refined_basalt = new BlockBuildingBlock("refined_basalt", Material.ROCK).setHardness(4f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		refined_basalt.setHarvestLevel("pickaxe", 1);
		
		refined_gneiss = new BlockBuildingBlock("refined_gneiss", Material.ROCK).setHardness(4f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		refined_gneiss.setHarvestLevel("pickaxe", 1);
		
		refined_marble = new BlockBuildingBlock("refined_marble", Material.ROCK).setHardness(4f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		refined_marble.setHarvestLevel("pickaxe", 1);
		
		refined_shale = new BlockBuildingBlock("refined_shale", Material.ROCK).setHardness(4f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		refined_shale.setHarvestLevel("pickaxe", 1);
		
		basalt_bricks = new BlockBuildingBlock("basalt_bricks", Material.ROCK).setHardness(4f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		basalt_bricks.setHarvestLevel("pickaxe", 1);
		
		gneiss_bricks = new BlockBuildingBlock("gneiss_bricks", Material.ROCK).setHardness(4f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		gneiss_bricks.setHarvestLevel("pickaxe", 1);
		
		marble_bricks = new BlockBuildingBlock("marble_bricks", Material.ROCK).setHardness(4f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		marble_bricks.setHarvestLevel("pickaxe", 1);
		
		shale_bricks = new BlockBuildingBlock("shale_bricks", Material.ROCK).setHardness(4f).setResistance(20f).setCreativeTab(VanillaEvolutionBlocks.tabBuilding);
		shale_bricks.setHarvestLevel("pickaxe", 1);
		
		adamantium_block = new BlockResourcesBlock("adamantium_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		adamantium_block.setHarvestLevel("pickaxe", 1);
		
		aluminum_block = new BlockResourcesBlock("aluminum_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		aluminum_block.setHarvestLevel("pickaxe", 1);
		
		amber_block = new BlockResourcesBlock("amber_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		amber_block.setHarvestLevel("pickaxe", 1);
		
		amethyst_block = new BlockResourcesBlock("amethyst_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		amethyst_block.setHarvestLevel("pickaxe", 1);
		
		beryl_block = new BlockResourcesBlock("beryl_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		beryl_block.setHarvestLevel("pickaxe", 1);
		
		bronze_block = new BlockResourcesBlock("bronze_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		bronze_block.setHarvestLevel("pickaxe", 1);
		
		carbon_block = new BlockResourcesBlock("carbon_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		carbon_block.setHarvestLevel("pickaxe", 1);
		
		cobalt_block = new BlockResourcesBlock("cobalt_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		cobalt_block.setHarvestLevel("pickaxe", 1);
		
		copper_block = new BlockResourcesBlock("copper_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		copper_block.setHarvestLevel("pickaxe", 1);
		
		dwarf_star_alloy_block = new BlockResourcesBlock("dwarf_star_alloy_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		dwarf_star_alloy_block.setHarvestLevel("pickaxe", 1);
		
		elemental_block = new BlockResourcesBlock("elemental_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		elemental_block.setHarvestLevel("pickaxe", 1);
		
		enderite_block = new BlockResourcesBlock("enderite_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		enderite_block.setHarvestLevel("pickaxe", 1);
		
		energetic_block = new BlockResourcesBlock("energetic_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		energetic_block.setHarvestLevel("pickaxe", 1);
		
		iridium_block = new BlockResourcesBlock("iridium_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		iridium_block.setHarvestLevel("pickaxe", 1);
		
		lead_block = new BlockResourcesBlock("lead_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		lead_block.setHarvestLevel("pickaxe", 1);
		
		magnetite_block = new BlockResourcesBlock("magnetite_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		magnetite_block.setHarvestLevel("pickaxe", 1);
		
		malachite_block = new BlockResourcesBlock("malachite_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		malachite_block.setHarvestLevel("pickaxe", 1);
		
		nickel_block = new BlockResourcesBlock("nickel_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		nickel_block.setHarvestLevel("pickaxe", 1);
		
		onyx_block = new BlockResourcesBlock("onyx_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		onyx_block.setHarvestLevel("pickaxe", 1);
		
		peridot_block = new BlockResourcesBlock("peridot_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		peridot_block.setHarvestLevel("pickaxe", 1);
		
		ruby_block = new BlockResourcesBlock("ruby_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		ruby_block.setHarvestLevel("pickaxe", 1);
		
		selenite_block = new BlockResourcesBlock("selenite_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		selenite_block.setHarvestLevel("pickaxe", 1);
		
		silver_block = new BlockResourcesBlock("silver_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		silver_block.setHarvestLevel("pickaxe", 1);
		
		slimey_block = new BlockResourcesBlock("slimey_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		slimey_block.setHarvestLevel("pickaxe", 1);
		
		tin_block = new BlockResourcesBlock("tin_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		tin_block.setHarvestLevel("pickaxe", 1);
		
		vibranium_block = new BlockResourcesBlock("vibranium_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		vibranium_block.setHarvestLevel("pickaxe", 1);
		
		zinc_block = new BlockResourcesBlock("zinc_block", Material.ROCK).setHardness(4f).setResistance(200f).setCreativeTab(VanillaEvolutionBlocks.tabBlocks);
		zinc_block.setHarvestLevel("pickaxe", 1);
	}
	
	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(malachite_ore, bacon_ore, torch_ore, wood_ore, limestone, basalt, gneiss, shale, nickel_ore, bauxite_ore, aluminum_ore, silver_ore, lead_ore,
				zinc_ore, carbon_ore, tin_ore, copper_ore, cobalt_ore, meteorite_ore, enderite_ore, ultrafood_ore, superfood_ore, amber_ore, onyx_ore, seasonal_ore, ruby_ore,
				peridot_ore, amethyst_ore, adamantium_ore, vibranium_ore, dwarf_star_alloy_ore, slime_ore, energetic_ore, ancient_ore, elemental_ore, selenite_ore, marble,
				beryl_ore, magnetite_ore, refined_basalt, refined_gneiss, refined_marble, refined_shale, basalt_bricks, gneiss_bricks, marble_bricks, shale_bricks, adamantium_block,
				aluminum_block, amber_block, amethyst_block, beryl_block, bronze_block, carbon_block, cobalt_block, copper_block, dwarf_star_alloy_block, elemental_block,
				enderite_block, energetic_block, iridium_block, lead_block, magnetite_block, malachite_block, nickel_block, onyx_block, peridot_block, ruby_block, selenite_block, 
				silver_block, slimey_block, tin_block, vibranium_block, zinc_block);
	}
	
	@SubscribeEvent
	public static void registerItemBlocks(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(new ItemBlock(malachite_ore).setRegistryName(malachite_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(bacon_ore).setRegistryName(bacon_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(torch_ore).setRegistryName(torch_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(wood_ore).setRegistryName(wood_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(limestone).setRegistryName(limestone.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(basalt).setRegistryName(basalt.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(gneiss).setRegistryName(gneiss.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(shale).setRegistryName(shale.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(nickel_ore).setRegistryName(nickel_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(bauxite_ore).setRegistryName(bauxite_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(aluminum_ore).setRegistryName(aluminum_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(silver_ore).setRegistryName(silver_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(lead_ore).setRegistryName(lead_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(zinc_ore).setRegistryName(zinc_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(carbon_ore).setRegistryName(carbon_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(tin_ore).setRegistryName(tin_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(copper_ore).setRegistryName(copper_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(cobalt_ore).setRegistryName(cobalt_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(meteorite_ore).setRegistryName(meteorite_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(enderite_ore).setRegistryName(enderite_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(ultrafood_ore).setRegistryName(ultrafood_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(superfood_ore).setRegistryName(superfood_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(amber_ore).setRegistryName(amber_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(onyx_ore).setRegistryName(onyx_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(seasonal_ore).setRegistryName(seasonal_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(ruby_ore).setRegistryName(ruby_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(peridot_ore).setRegistryName(peridot_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(amethyst_ore).setRegistryName(amethyst_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(adamantium_ore).setRegistryName(adamantium_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(vibranium_ore).setRegistryName(vibranium_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(dwarf_star_alloy_ore).setRegistryName(dwarf_star_alloy_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(slime_ore).setRegistryName(slime_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(energetic_ore).setRegistryName(energetic_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(ancient_ore).setRegistryName(ancient_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(elemental_ore).setRegistryName(elemental_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(selenite_ore).setRegistryName(selenite_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(marble).setRegistryName(marble.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(beryl_ore).setRegistryName(beryl_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(magnetite_ore).setRegistryName(magnetite_ore.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(refined_basalt).setRegistryName(refined_basalt.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(refined_gneiss).setRegistryName(refined_gneiss.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(refined_marble).setRegistryName(refined_marble.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(refined_shale).setRegistryName(refined_shale.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(basalt_bricks).setRegistryName(basalt_bricks.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(gneiss_bricks).setRegistryName(gneiss_bricks.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(marble_bricks).setRegistryName(marble_bricks.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(shale_bricks).setRegistryName(shale_bricks.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(adamantium_block).setRegistryName(adamantium_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(aluminum_block).setRegistryName(aluminum_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(amber_block).setRegistryName(amber_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(amethyst_block).setRegistryName(amethyst_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(beryl_block).setRegistryName(beryl_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(bronze_block).setRegistryName(bronze_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(carbon_block).setRegistryName(carbon_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(cobalt_block).setRegistryName(cobalt_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(copper_block).setRegistryName(copper_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(dwarf_star_alloy_block).setRegistryName(dwarf_star_alloy_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(elemental_block).setRegistryName(elemental_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(enderite_block).setRegistryName(enderite_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(energetic_block).setRegistryName(energetic_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(iridium_block).setRegistryName(iridium_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(lead_block).setRegistryName(lead_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(magnetite_block).setRegistryName(magnetite_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(malachite_block).setRegistryName(malachite_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(nickel_block).setRegistryName(nickel_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(onyx_block).setRegistryName(onyx_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(peridot_block).setRegistryName(peridot_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(ruby_block).setRegistryName(ruby_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(selenite_block).setRegistryName(selenite_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(silver_block).setRegistryName(silver_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(slimey_block).setRegistryName(slimey_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(tin_block).setRegistryName(tin_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(vibranium_block).setRegistryName(vibranium_block.getRegistryName()));
		event.getRegistry().registerAll(new ItemBlock(zinc_block).setRegistryName(zinc_block.getRegistryName()));
	}
	
	@SubscribeEvent
	public static void registerRenders(ModelRegistryEvent event) {
		registerRender(Item.getItemFromBlock(malachite_ore));
		registerRender(Item.getItemFromBlock(bacon_ore));
		registerRender(Item.getItemFromBlock(torch_ore));
		registerRender(Item.getItemFromBlock(wood_ore));
		registerRender(Item.getItemFromBlock(limestone));
		registerRender(Item.getItemFromBlock(basalt));
		registerRender(Item.getItemFromBlock(gneiss));
		registerRender(Item.getItemFromBlock(shale));
		registerRender(Item.getItemFromBlock(nickel_ore));
		registerRender(Item.getItemFromBlock(bauxite_ore));
		registerRender(Item.getItemFromBlock(aluminum_ore));
		registerRender(Item.getItemFromBlock(silver_ore));
		registerRender(Item.getItemFromBlock(lead_ore));
		registerRender(Item.getItemFromBlock(zinc_ore));
		registerRender(Item.getItemFromBlock(carbon_ore));
		registerRender(Item.getItemFromBlock(tin_ore));
		registerRender(Item.getItemFromBlock(copper_ore));
		registerRender(Item.getItemFromBlock(cobalt_ore));
		registerRender(Item.getItemFromBlock(meteorite_ore));
		registerRender(Item.getItemFromBlock(enderite_ore));
		registerRender(Item.getItemFromBlock(ultrafood_ore));
		registerRender(Item.getItemFromBlock(superfood_ore));
		registerRender(Item.getItemFromBlock(amber_ore));
		registerRender(Item.getItemFromBlock(onyx_ore));
		registerRender(Item.getItemFromBlock(seasonal_ore));
		registerRender(Item.getItemFromBlock(ruby_ore));
		registerRender(Item.getItemFromBlock(peridot_ore));
		registerRender(Item.getItemFromBlock(amethyst_ore));
		registerRender(Item.getItemFromBlock(adamantium_ore));
		registerRender(Item.getItemFromBlock(vibranium_ore));
		registerRender(Item.getItemFromBlock(dwarf_star_alloy_ore));
		registerRender(Item.getItemFromBlock(slime_ore));
		registerRender(Item.getItemFromBlock(energetic_ore));
		registerRender(Item.getItemFromBlock(ancient_ore));
		registerRender(Item.getItemFromBlock(elemental_ore));
		registerRender(Item.getItemFromBlock(selenite_ore));
		registerRender(Item.getItemFromBlock(marble));
		registerRender(Item.getItemFromBlock(beryl_ore));
		registerRender(Item.getItemFromBlock(magnetite_ore));
		registerRender(Item.getItemFromBlock(refined_basalt));
		registerRender(Item.getItemFromBlock(refined_gneiss));
		registerRender(Item.getItemFromBlock(refined_marble));
		registerRender(Item.getItemFromBlock(refined_shale));
		registerRender(Item.getItemFromBlock(basalt_bricks));
		registerRender(Item.getItemFromBlock(gneiss_bricks));
		registerRender(Item.getItemFromBlock(marble_bricks));
		registerRender(Item.getItemFromBlock(shale_bricks));
		registerRender(Item.getItemFromBlock(adamantium_block));
		registerRender(Item.getItemFromBlock(aluminum_block));
		registerRender(Item.getItemFromBlock(amber_block));
		registerRender(Item.getItemFromBlock(amethyst_block));
		registerRender(Item.getItemFromBlock(beryl_block));
		registerRender(Item.getItemFromBlock(bronze_block));
		registerRender(Item.getItemFromBlock(carbon_block));
		registerRender(Item.getItemFromBlock(cobalt_block));
		registerRender(Item.getItemFromBlock(copper_block));
		registerRender(Item.getItemFromBlock(dwarf_star_alloy_block));
		registerRender(Item.getItemFromBlock(elemental_block));
		registerRender(Item.getItemFromBlock(enderite_block));
		registerRender(Item.getItemFromBlock(energetic_block));
		registerRender(Item.getItemFromBlock(iridium_block));
		registerRender(Item.getItemFromBlock(lead_block));
		registerRender(Item.getItemFromBlock(magnetite_block));
		registerRender(Item.getItemFromBlock(malachite_block));
		registerRender(Item.getItemFromBlock(nickel_block));
		registerRender(Item.getItemFromBlock(onyx_block));
		registerRender(Item.getItemFromBlock(peridot_block));
		registerRender(Item.getItemFromBlock(ruby_block));
		registerRender(Item.getItemFromBlock(selenite_block));
		registerRender(Item.getItemFromBlock(silver_block));
		registerRender(Item.getItemFromBlock(slimey_block));
		registerRender(Item.getItemFromBlock(tin_block));
		registerRender(Item.getItemFromBlock(vibranium_block));
		registerRender(Item.getItemFromBlock(zinc_block));
	}
	
	public static void registerRender(Item item) {
		ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation( item.getRegistryName(), "inventory"));
	}
	
	static final CreativeTabs tabOres = (new CreativeTabs("tabOres") {

		@Override
		public ItemStack getTabIconItem() {
			return new ItemStack(malachite_ore);
		}
		
		
		
	});
	
	static final CreativeTabs tabBuilding = (new CreativeTabs("tabBuilding") {

		@Override
		public ItemStack getTabIconItem() {
			return new ItemStack(refined_basalt);
		}
		
		
		
	});
	
	static final CreativeTabs tabBlocks = (new CreativeTabs("tabBlocks") {

		@Override
		public ItemStack getTabIconItem() {
			return new ItemStack(beryl_block);
		}
		
		
		
	});
}
