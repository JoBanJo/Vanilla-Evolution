package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemSeasonalGem extends Item{
	
	public ItemSeasonalGem(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
