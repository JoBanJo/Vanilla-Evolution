package com.evep.evepmod.items;

import java.awt.List;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemEnderite extends Item{
	
	public ItemEnderite(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}
	
	public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean show){
		list.add("One of the Strongest Materials Ever Found");
	}

}
