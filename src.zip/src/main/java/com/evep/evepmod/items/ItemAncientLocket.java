package com.evep.evepmod.items;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class ItemAncientLocket extends Item{
	
	public ItemAncientLocket(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}
}
