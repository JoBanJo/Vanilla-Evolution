package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemNickelIngot extends Item{
	
	public ItemNickelIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}
}
