package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemElementalIngot extends Item{
	
	public ItemElementalIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
