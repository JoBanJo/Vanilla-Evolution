package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemCopperIngot extends Item{
	
	public ItemCopperIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
