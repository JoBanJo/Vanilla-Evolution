package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemMeteoriteShard extends Item{
	
	public ItemMeteoriteShard(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
