package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemCobaltIngot extends Item{
	
	public ItemCobaltIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
