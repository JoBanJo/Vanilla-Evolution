package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemAmethyst extends Item{
	
	public ItemAmethyst(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
