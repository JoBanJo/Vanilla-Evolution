package com.evep.evepmod.init;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class VanillaEvolutionCrafting {
	
	public static void init(){
		GameRegistry.addSmelting(VanillaEvolutionBlocks.malachite_ore, new ItemStack(VanillaEvolutionItems.malachite_ingot, 1), 0.5f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.bauxite_ore, new ItemStack(VanillaEvolutionBlocks.aluminum_ore, 1), 0.5f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.nickel_ore, new ItemStack(VanillaEvolutionItems.nickel_ingot, 1), 1f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.aluminum_ore, new ItemStack(VanillaEvolutionItems.aluminum_ingot, 1), 0.8f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.silver_ore, new ItemStack(VanillaEvolutionItems.silver_ingot, 1), 0.3f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.lead_ore, new ItemStack(VanillaEvolutionItems.lead_ingot, 1), 0.7f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.zinc_ore, new ItemStack(VanillaEvolutionItems.zinc_ingot, 1), 1f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.carbon_ore, new ItemStack(VanillaEvolutionItems.carbon_ingot, 1), 1f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.tin_ore, new ItemStack(VanillaEvolutionItems.tin_ingot, 1), 0.8f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.copper_ore, new ItemStack(VanillaEvolutionItems.copper_ingot, 1), 0.3f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.cobalt_ore, new ItemStack(VanillaEvolutionItems.cobalt_ingot, 1), 0.7f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.adamantium_ore, new ItemStack(VanillaEvolutionItems.adamantium_ingot, 1), 0.7f);
		GameRegistry.addSmelting(VanillaEvolutionItems.meteorite_shard, new ItemStack(VanillaEvolutionItems.iridium_ingot, 1), 0.8f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.magnetite_ore, new ItemStack(VanillaEvolutionItems.magnetite_ingot, 1), 1f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.limestone, new ItemStack(VanillaEvolutionBlocks.marble, 1), 0.2f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.basalt, new ItemStack(VanillaEvolutionBlocks.refined_basalt, 1), 0.2f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.gneiss, new ItemStack(VanillaEvolutionBlocks.refined_gneiss, 1), 0.2f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.marble, new ItemStack(VanillaEvolutionBlocks.refined_marble, 1), 0.2f);
		GameRegistry.addSmelting(VanillaEvolutionBlocks.shale, new ItemStack(VanillaEvolutionBlocks.refined_shale, 1), 0.2f);
	}

}
