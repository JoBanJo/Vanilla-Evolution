package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemBeryl extends Item{
	
	public ItemBeryl(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
