package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemEnergeticOrb extends Item{
	
	public ItemEnergeticOrb(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
