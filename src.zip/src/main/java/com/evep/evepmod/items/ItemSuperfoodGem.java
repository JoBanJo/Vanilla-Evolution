package com.evep.evepmod.items;

import java.awt.List;
import java.util.ArrayList;

import javax.annotation.Nullable;

import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemSuperfoodGem extends Item{
	
	public ItemSuperfoodGem(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}
	
//	@SideOnly(Side.CLIENT)
//	public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn)  {
//		list.add("It Looks Very Delicious");
//	    }
	
//	@Override
//	public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean show){
//		list.add("It Looks Very Delicious");
//	}

	
//	@Override
//	public void addInformation(ItemStack stack, World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
//		super.addInformation(stack, worldIn, tooltip, flagIn);
//
//		tooltip.add(I18n.format("�1It Looks Very Delicious"));
//	}
}