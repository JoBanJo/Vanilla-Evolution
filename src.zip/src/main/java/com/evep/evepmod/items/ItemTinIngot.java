package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemTinIngot extends Item{
	
	public ItemTinIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
