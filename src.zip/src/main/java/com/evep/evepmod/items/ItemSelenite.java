package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemSelenite extends Item{
	
	public ItemSelenite(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
