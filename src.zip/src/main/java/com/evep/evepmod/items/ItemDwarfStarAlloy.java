package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemDwarfStarAlloy extends Item{
	
	public ItemDwarfStarAlloy(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
