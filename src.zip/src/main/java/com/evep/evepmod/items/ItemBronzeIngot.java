package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemBronzeIngot extends Item{
	
	public ItemBronzeIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
