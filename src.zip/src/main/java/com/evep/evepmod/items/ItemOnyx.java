package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemOnyx extends Item{
	
	public ItemOnyx(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
