package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemImbuedRod extends Item{
	
	public ItemImbuedRod(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
