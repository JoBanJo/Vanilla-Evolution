package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemSlimeGem extends Item{
	
	public ItemSlimeGem(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
