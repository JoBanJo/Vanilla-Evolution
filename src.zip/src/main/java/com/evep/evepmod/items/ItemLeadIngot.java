package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemLeadIngot extends Item{
	
	public ItemLeadIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
