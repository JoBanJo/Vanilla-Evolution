package com.evep.evepmod.items.tools;

import com.evep.evepmod.init.VanillaEvolutionItems;

import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.ToolMaterial;

public class ItemBronzePickaxe extends ItemPickaxe{
	
	public ItemBronzePickaxe(String name, ToolMaterial material, float damage, float speed) {
		super(material);
		this.setRegistryName(name);
		this.setUnlocalizedName(name);
	}
	
	@Override
	public boolean getIsRepairable(ItemStack armor, ItemStack stack){
		return stack.getItem() == VanillaEvolutionItems.bronze_ingot;
	}

}
