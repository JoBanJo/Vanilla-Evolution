package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemCarbonIngot extends Item{
	
	public ItemCarbonIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
