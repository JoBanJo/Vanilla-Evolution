package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemPeridot extends Item{
	
	public ItemPeridot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
