package com.evep.evepmod.items;

import net.minecraft.item.Item;

public class ItemSilverIngot extends Item{
	
	public ItemSilverIngot(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
	}

}
